﻿SET QUOTED_IDENTIFIER ON;

TRUNCATE TABLE Segmentation.SegmentCustomer
DELETE FROM Segmentation.Segment
TRUNCATE TABLE Fact.LoyaltyAccount
TRUNCATE TABLE Fact.CustomerProfile
DELETE FROM Fact.Customer
DELETE FROM Dim.EarningType
DELETE FROM Dim.LoyaltyProgram