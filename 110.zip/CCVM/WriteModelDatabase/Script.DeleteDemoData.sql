﻿SET QUOTED_IDENTIFIER ON

DELETE FROM [dbo].[UndispatchedEvent]

DELETE FROM [dbo].[CouponAllocations]

DELETE FROM [dbo].[TextInfos]

DELETE FROM [dbo].[CouponTemplates]

DELETE FROM [dbo].[CouponCodes]

DELETE FROM [dbo].[CouponDesigns]

DELETE FROM [dbo].[CouponTemplatesDistributionChannels]

DELETE FROM [dbo].[CouponTemplateSerialNumberRanges]

DELETE FROM [dbo].[CouponTemplateSerialNumberRangesGenerations]

DELETE FROM [dbo].[VoucherCodes]

DELETE FROM [dbo].[VoucherDesigns]

DELETE FROM [dbo].[VoucherTemplateTextInfos]

DELETE FROM [dbo].[VoucherTemplates]
