﻿
  UPDATE dbo.Location
  SET LocationGroupId = null

  UPDATE dbo.LocationGroup
  SET LocationId = null

  DELETE FROM dbo.Location

  DELETE FROM dbo.LocationGroup
  WHERE [LocationGroupId] <> 0
 
  DELETE FROM dbo.LocationGroupType

  DELETE FROM [dbo].[UndispatchedEvent]
  WHERE EventStreamId <> 'Location-0'

  IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE  TABLE_SCHEMA = N'dbo' AND TABLE_NAME = N'Commits')
  BEGIN
	 DELETE FROM [dbo].[Commits]
	 WHERE StreamIdOriginal <> 'Location-0'
  END
