﻿/*
Delete demo data Script Template							
*/

PRINT 'VE.Loyalty.Database scripts deleted'

TRUNCATE Table Loyalty.CustomerIdentifier
GO
PRINT 'Loyalty.CustomerIdentifier deleted'

DELETE FROM Loyalty.ExchangeRate
GO
PRINT 'Loyalty.ExchangeRate deleted'

TRUNCATE Table Loyalty.AccountMerge
GO
PRINT 'Loyalty.AccountMerge deleted'

TRUNCATE Table Loyalty.AccountBalance
GO
PRINT 'Loyalty.AccountBalance deleted'

TRUNCATE Table Loyalty.MovementRedemption
GO
PRINT 'Loyalty.MovementRedemption deleted'

TRUNCATE Table Loyalty.MovementCancellation
GO
PRINT 'Loyalty.MovementCancellation deleted'

DELETE FROM Loyalty.Movement
WHERE ReservationMovementId is not null

DELETE FROM Loyalty.Movement
GO
PRINT 'Loyalty.Movement deleted'

DELETE FROM Loyalty.Account
GO
PRINT 'Loyalty.Account deleted'

DELETE FROM Loyalty.LoyaltyCard
GO
PRINT 'Loyalty.LoyaltyCard deleted'

DELETE FROM Loyalty.CardRange
GO
PRINT 'Loyalty.CardRange deleted'

DELETE FROM  Loyalty.CustomerIdentifierType
GO
PRINT 'Loyalty.CustomerIdentifierType deleted'

TRUNCATE Table Loyalty.Tier
GO
PRINT 'Loyalty.Tier deleted'

TRUNCATE Table Loyalty.LoyaltyProgramMandator
GO
PRINT 'Loyalty.LoyaltyProgramMandator deleted'

DELETE FROM Loyalty.EarningSubtype
GO
PRINT 'Loyalty.EarningSubtype deleted'

DELETE FROM Loyalty.EarningTypeValidityPeriod
GO
PRINT 'Loyalty.EarningTypeValidityPeriod deleted'

DELETE FROM Loyalty.EarningType
GO
PRINT 'Loyalty.EarningType deleted'

DELETE FROM Loyalty.LoyaltyProgram WHERE LoyaltyProgramId <> 0
GO
PRINT 'Loyalty.LoyaltyProgram deleted'

DELETE FROM Loyalty.AccountLimitConfiguration
GO
PRINT 'Loyalty.AccountLimitConfiguration deleted'

DELETE FROM Settings.Mandator
GO
PRINT 'Settings.Mandator deleted'

DELETE FROM Settings.Channel
GO
PRINT 'Settings.Channel deleted'

DELETE FROM Loyalty.Customer
GO
PRINT 'Loyalty.Customer deleted'

DELETE FROM [dbo].[UndispatchedEventSemaphore]
DELETE FROM [dbo].[UndispatchedEvent]

IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = N'dbo' AND TABLE_NAME = N'Commits')
BEGIN
	DELETE FROM [dbo].[Commits]
END

PRINT 'Loyalty events deleted'

DELETE FROM [dbo].[AtomFeedConfiguration]
PRINT 'Loyalty AtomFeedConfiguration deleted'