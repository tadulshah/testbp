﻿/*
Delete demo data Script Template							
*/

DELETE FROM [MediaService].[Documents]
PRINT 'MediaService Documents deleted'