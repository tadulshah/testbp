﻿DELETE FROM [ItemSearch].[Categories]

DELETE FROM [ItemSearch].[DepartmentGroups]

DELETE FROM [ItemSearch].[Departments]

DELETE FROM [ItemSearch].[ItemGroups]

DELETE FROM [ItemSearch].[PaymentMedia]

DELETE FROM [ItemSearch].[PosItems]