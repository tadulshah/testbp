﻿SET QUOTED_IDENTIFIER ON;

DELETE FROM [Organization].[FieldOfInterest]

DELETE FROM [Organization].[ServedArea]

DELETE FROM [Organization].[OrganizationIdentifier]

DELETE FROM [Organization].[OrganizationContactPerson]

DELETE FROM [Customer].[CustomerPostalAddress]

DELETE FROM [Customer].[CustomerTelephoneNumber]

DELETE FROM [Customer].[CustomerDevice]

DELETE FROM [Customer].[CustomerEmailAddress]

DELETE FROM [Customer].[CustomerSettings]

DELETE FROM [ext].[Customer_CustomerProfile]

DELETE FROM [IndividualPerson].[HouseholdInvitationToken]

DELETE FROM [IndividualPerson].[HouseholdMember]

DELETE FROM [IndividualPerson].[Household]

DELETE FROM [Consents].[CustomerConsent]

DELETE FROM [Customer].[CustomerProfile]

DELETE FROM [Customer].[CustomerList]

DELETE FROM [Consents].[Consent]